<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php"); ?>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <div class="link">
            <ui>
                <li class="lil"><a href="index.php">首頁</a></li>
                <li class="lil_down">
                    <a href="order.php?page=o_one">我要購買</a>
                    <div class="dropdown-content">
                        <a href="order_info.php?page=o_info">訂單資訊</a>
                    </div>
                </li>
                <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                <li class="lil"><a href="farmer_login.php">會員登入</a></li>
            </ui>
        </div>
        <center>
            <form action="farmer_pro.php?page=login" method="post">
                <table width="30%" border="0" cellspacing="0">
                    <tr>
                        <td colspan="2" class="t1">會員登入</td>
                    </tr>
                    <tr>
                        <td width="27%">帳 號</td>
                        <td width="73%"><input type="text" name="acc"></td>
                    </tr>
                    <tr>
                        <td>密 碼</td>
                        <td><input type="password" name="password"></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="submit" value="登入">　　<input type="reset" value="清除">
                            <div align="right"><a href="farmer_logist.php">註冊會員</a></div>
                        </td>
                    </tr>
                </table>
            </form>
        </center>
    </div>
</body>

</html>