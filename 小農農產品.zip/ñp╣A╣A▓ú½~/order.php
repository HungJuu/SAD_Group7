<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php"); ?>

    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="JQ/jquery-3.2.1.js"></script>
    <script src="JQ/jquery-3.2.1.min.js"></script>
    <script>
        function booking() {
            var mun = 0;
            // /[@#\$%\^&\*]+/g
            // new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]","i"); 
            var er = /[{}!@#$%^&*()_+='" ]+/;

            var text = $('#phone').val()
            if (er.test(text) == true) {
                alert('出現非法文字');
            }

            if ($('#o_name').val() == "") {
                alert('訂購人姓名不得為空值');
            } else {
                mun += 1;
            }
            if ($('#phone').val() == "") {
                alert('手機號碼不得為空值');
            } else {
                mun += 1;
            }
            if ($('#date').val() == "") {
                alert('日期不得為空值');
            } else {
                mun += 1;
            }
            if ($('#tot').val() == "") {
                alert('張數不得為空值');
            } else {
                mun += 1;
            }
            if (mun == 4) {
                sub.submit();
            }
        }

        function jujube() {
            var s = document.getElementById("paragraph");
            if (s.style.display == "none") {
                s.style.display = "block";
            } else {
                s.style.display = "none";
            }
        }

        function mango() {
            var m = document.getElementById("fruit2");
            if (m.style.display == "none") {
                m.style.display = "block";
            } else {
                m.style.display = "none";
            }
        }

        function banana() {
            var y = document.getElementById("fruit3");
            if (y.style.display == "none") {
                y.style.display = "block";
            } else {
                y.style.display = "none";
            }
        }

        function cookies() {
            var y = document.getElementById("fruit4");
            if (y.style.display == "none") {
                y.style.display = "block";
            } else {
                y.style.display = "none";
            }
        }
        $(document).ready(function() {
            $("#date").change(function() {
                var d = new Date($("#date").val());
                $("#week").val("星期" + mo[d.getDay()]);
            })
            $("#recipient_nums").change(function() {
                $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
            })
            $("#recipient_UnitPrice").change(function() {
                $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
            })
            $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
        });

        function myFunction() {
            // Get the checkbox
            var checkBox = document.getElementById("myCheck");
            // Get the output text
            var text = document.getElementById("text");

            // If the checkbox is checked, display the output text
            if (checkBox.checked == true) {
                //           alert($("#o_name").val());
                $("#recipient_name").val($("#o_name").val());
                $("#recipient_phone").val($("#o_phone").val());
            } else {
                $("#recipient_name").val("");
                $("#recipient_phone").val("");
                text.style.display = "none";
            }
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <div class="link">
            <ui>
                <li class="lil"><a href="index.php">首頁</a></li>
                <li class="lil_down">
                    <a href="order.php?page=o_one">我要購買</a>
                    <div class="dropdown-content">
                        <a href="order_info.php?page=o_info">訂單資訊</a>
                    </div>
                </li>
                <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                <li class="lil"><a href="farmer_pro.php?page=logout">登　出</a></li>
            </ui>
        </div>
        <center>
            <?php if (@$_SESSION['state'] == "1") { ?>
                <?php if (@$_GET['page'] == "o_one") { ?>
                    <table>
                        <tr>
                            <td>
                                <button value="1 ~ 3月" onclick="jujube()">1 ~ 3月棗子 </button>　　
                                <button value="4 ~ 6月" onclick="mango()">4 ~ 6月土芒果</button>　　
                                <button value="7 ~ 9月" onclick="banana()">7 ~ 9月香蕉</button>　　
                                <button value="小農農加工" onclick="cookies()">小農農加工</button>　　
                            </td>
                        </tr>
                    </table>
                    <div id="paragraph">
                        <b>蜜 棗🍏</b><br>
                        高雄市燕巢區蜜棗種植面積約600公頃，年產量3000多公噸蜜棗的指標性產區。蜜棗產期是國曆12月下旬<br>
                        至翌年3月上旬，盛產期在1月。為保持蜜棗品質，每年產季過後，農民們須像望子成龍的父親一般，對蜜棗樹<br>
                        徹底的截枝，只留下小腿一般高的樹幹，讓果樹重新來過。<br>
                    </div>

                    <div id="fruit2">
                        <b>土芒果🥭</b><br>
                        最大的特點為抗病蟲害強，耐旱因此管理容易，果實具有濃郁的香味，外皮為黃綠色的土芒果，<br>
                        果實雖小且纖維粗，但酸甜有味、香氣濃郁，常被用於製作情人果、蜜餞、芒果乾。台灣人<br>
                        吃遍大大小小芒果後，才驚覺那長在高高樹上的小小土芒果，才是最香、最甜、最好吃的品種，<br>
                        有土芒果獨有的香氣美味。<br>
                    </div>
                    <div id="fruit3">
                        <b>旗山香蕉🍌</b><br>
                        旗山位於高雄山區和平原的交界，擁有適宜的氣候條件和優越的地理環境，<br>
                        使得種植出來的香蕉帶有獨特的香氣，綿密甜Q、風味馥郁，有「香蕉王國」之稱；<br>
                        近年來，旗山蕉農轉型成為優質小農，使得所種植出來的香蕉品質更加精緻且穩定。<br>
                    </div>


                    <div id="fruit4">
                        <form action="?page=o_two" method="POST">
                            <table width="50%">
                                <td colspan="2" align="center" class="t1">美　味　果　乾<br></td>
                                <tr>
                                    <td rowspan="4">
                                        <p></p>
                                        <img class="img-fluid" title="banana" src="image\DriedBanana.jfif" alt="banana" width="200" height="300" />
                                    </td>
                                    <td align="left">
                                        <p></p>售價 150元 / 包
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left">數量
                                        <select name="nums" id="nums">
                                            <option>---請選擇---</option>
                                            <?php for ($i = 1; $i <= 15; $i++) { ?>
                                                <option value="<?= $i ?>"><?= $i ?></option>
                                            <?php    } ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left">運費 130元</td>
                                </tr>
                                <tr>
                                    <td align="left" colspan="2">
                                        <button onclick="">我想購買</button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                <?php   } ?>

                <?php if (@$_GET['page'] == "o_two") {
                  //  echo "$_SESSION[acc]";
                    $roe = mysqli_query($con, "select * from users where acc = '$_SESSION[acc]'");
                    while ($roo = mysqli_fetch_array($roe)) {
                ?>
                        <form method="post" id="sub" action="farmer_pro.php?page=order_two">
                            <table border="0" cellpadding="0" cellspacing="0" width="50%">
                                <tr>
                                    <td colspan="2" class="t1">小農農訂購資訊<input type="hidden" name="select" value="select"></td>
                                </tr>
                                <tr>
                                    <td><br>訂購人姓名</td>
                                    <td>
                                        <input type="text" id="o_name" name="o_name" value="<?= $roo['c_name']?>" readonly>
                                    </td>
                                </tr>
                                <tr>
                                    <td>手機號碼</td>
                                    <td>
                                        <input type="text" id="o_phone" name="o_phone" value="<?=$roo['c_tel']?>" readonly><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" align="center">
                                        <hr size="2" color="#AAA" width="80%">
                                    </td>
                                </tr>
                                <td>收件人姓名<input type="checkbox" id="myCheck" onclick="myFunction()">同上 </td>
                                <td>
                                    <!--   <p id="text" style="display:none">Checkbox is CHECKED!</p> -->
                                    <input type="text" id="recipient_name" name="recipient_name">
                                </td>
                                </tr>
                                <tr>
                                    <td>手機號碼</td>
                                    <td>
                                        <input type="text" id="recipient_phone" name="recipient_phone"><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td>收件地址</td>
                                    <td><input type="text" id="recipient_addr" name="recipient_addr"><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td>產品名稱</td>
                                    <td><input type="text" id="recipient_product" name="recipient_product" value="香蕉果乾"><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td>購買數量</td>
                                    <td><input type="number" id="recipient_nums" name="recipient_nums" value="<?= $_POST['nums'] ?>"><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td>售價 / 包</td>
                                    <td><input type="text" id="recipient_UnitPrice" name="recipient_UnitPrice" value="150" readonly><br>
                                    </td>
                                </tr>

                                <tr>
                                    <td>運　費</td>
                                    <td><input type="text" id="recipient_fare" name="recipient_fare" value="130元" readonly><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td>總計金額</td>
                                    <td align="center"><input type="text" size="7" id="recipient_tot" name="recipient_tot" readonly><br>
                                    </td>
                                </tr>
                                <tr>
                                    <td><br>驗證碼</td>
                                    <td><br><input type="text" name="ran"></td>
                                </tr>
                                <tr>
                                    <td><?php include('ran.php') ?></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>由小到大</td>
                                    <td>
                                        <input type="button" onClick="booking()" value="送出訂單">　　
                                        <input type="reset" value="清除">
                                    </td>
                                </tr>
                            </table>
                        </form>
                <?php
                    }
                } ?>
            <?php } else {
                alert('請先登入');
                location("farmer_login.php");
            } ?>
        </center>
    </div>
</body>

</html>