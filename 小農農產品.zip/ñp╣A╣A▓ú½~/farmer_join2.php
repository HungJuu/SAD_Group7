<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php
    include("conn.php");
    $roe = mysqli_query($con, "select * from farm_experience_manager where no = '$_GET[id]'");
    $farm_ex_m = mysqli_fetch_array($roe);
    ?>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="JQ/jquery-3.2.1.js"></script>
    <script src="JQ/jquery-3.2.1.min.js"></script>
    <script>
        function JoinFarm() {
            document.getElementById("JoinFarm").style.display = "none";

            //  game = true;
            document.getElementById("JoinToKnow").style.display = "none";
            document.getElementById("JoinFarm_2").style.display = "block";

        }

        function join() {
            var mun = 0;
            // /[@#\$%\^&\*]+/g
            // new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]","i"); 
            var er = /[{}!@#$%^&*()_+='" ]+/;

            var text = $('#experience_tel').val()
            if (er.test(text) == true) {
                alert('出現非法文字');
            }

            if ($('#experience_name').val() == "") {
                alert('請輸入聯絡人姓名');
            } else {
                mun += 1;
            }
            if ($('#experience_nums').val() == "") {
                alert('請選擇參加人數');
            } else {
                mun += 1;
            }
            if ($('#experience_mail').val() == "") {
                alert('電子信箱不得為空值');
            } else {
                mun += 1;
            }
            if ($('#experience_tel').val() == "") {
                alert('請輸入聯絡人手機號碼');
            } else {
                mun += 1;
            }

            if (mun == 4) {
                sub.submit();
            }
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <?php if (@$_SESSION['state'] == "1") {        ?>
            <div class="link">
                <ui>
                    <li class="lil"><a href="index.php">首頁</a></li>
                    <li class="lil_down">
                        <a href="order.php?page=o_one">我要購買</a>
                        <div class="dropdown-content">
                            <a href="order_info.php?page=o_info">訂單資訊</a>
                        </div>
                    </li>
                    <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                    <li class="lil"><a href="farmer_pro.php?page=logout">登　出</a></li>
                </ui>
            </div>
        <?php } else { ?>
            <div class="link">
                <ui>
                    <li class="lil"><a href="index.php">首頁</a></li>
                    <li class="lil_down">
                        <a href="order.php?page=o_one">我要購買</a>
                        <div class="dropdown-content">
                            <a href="order_info.php?page=o_info">訂單資訊</a>
                        </div>
                    </li>
                    <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                    <div id="log">
                        <li class="lil"><a href="farmer_login.php">會員登入</a></li>
                    </div>
                </ui>
            </div>
        <?php } ?>
        <center>
            <?php if ($farm_ex_m['experience_nums'] <= $farm_ex_m['experience_people']) {
                alert("該場次已額滿");
                location("farmer_join.php");
            } else {

            ?>
                <div id="JoinFarm_2">
                    <div id="imgs">
                        <img class="img-fluid" title="experience" src="image\POST.png" alt="banana" width="250" height="350" />
                    </div>

                    <form method="POST" action="farmer_pro.php?page=farmer_experience" id="sub">
                        <table width="45%" height="35%" cellpadding="0" cellspacing="0" align="center">
                            <tr>
                                <td align="center" class="t1" colspan="2">預約資料填寫<br></td>
                            </tr>
                            <tr>
                                <td align="left">　活動場次　<input id="experience_no" name="experience_no" type="text" value="<?= $farm_ex_m['no'] ?>" readonly></td>
                            </tr>
                            <tr>
                                <td align="left">　活動日期　<input id="experience_date" name="experience_date" type="text" value="<?= $farm_ex_m['experience_date'] ?>" readonly></td>
                                <td align="left">　活動時段　<input id="experience_time" name="experience_time" type="text" value="<?= $farm_ex_m['experience_time'] ?>" readonly></td>
                            </tr>
                            <tr>
                                <td align="left">　★ 參加人數　<select id="experience_nums" name="experience_nums">
                                        <option>---請選擇---</option>
                                        <?php for ($i = 1; $i <= 8; $i++) { ?>
                                            <option value="<?= $i ?>"><?= $i ?></option>
                                        <?php    } ?>
                                    </select>
                                </td>
                                <td align="left">　★ 聯絡人姓名 <input id="experience_name" name="experience_name" type="text"></td>

                            </tr>
                            <tr>
                                <td align="left">　★ 聯絡人手機 <input id="experience_tel" name="experience_tel" type="text"></td>
                                <td align="left">　★ 聯絡人信箱 <input id="experience_mail" name="experience_mail" type="text"></td>
                            </tr>
                            <tr>
                                <td align="center" colspan="2">
                                    <input type="button" onClick="join()" value="參　加">　
                                    <input type="reset" value="清　除">
                                </td>
                            </tr>
                        </table>
                    </form>
                    <div id="imgs2">
                        <img class="img-fluid" title="experience" src="image\POST.png" alt="banana" width="250" height="350" />
                    </div>

                </div>

            <?php } ?>
    </div>
    </center>
</body>

</html>