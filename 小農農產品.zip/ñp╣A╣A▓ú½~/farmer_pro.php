<meta content="text/html" http-equiv="Content-Type" charset="utf-8">

<?php
include('conn.php');

//會員登入 
if (@$_GET['page'] == "login") {
    $roe = mysqli_query($con, "select * from users where acc = '$_POST[acc]'");
    $ros = mysqli_fetch_array($roe);

    if (mysqli_num_rows($roe) == 0) {
        alert('請先註冊');
        location("farmer_logist.php");
    } else {
        if (@$_POST['acc'] == $ros['acc']) {
            if (@$_POST['password'] == $ros['password']) {
                // @$_SESSION['acc'] = $_POST['acc'];

                @$_SESSION['state'] = "1";
                @$_SESSION['acc'] = $_POST['acc'];
                alert('密碼正確');
                if ($ros['auth'] == "2") {
                    location('farmer_manager.php');
                } else {
                    location('order.php');
                }
            } else {
                alert('密碼錯誤');
                location('farmer_login.php');
            }
        } else {
            alert('帳號錯誤');
            location('farmer_login.php');
        }
    }
}
//會員註冊 
if (@$_GET['page'] == "logist") {
    mysqli_query($con, "insert into users values('','$_POST[c_name]','$_POST[acc]','$_POST[password]','$_POST[c_mail]','$_POST[c_tel]','$_POST[identity]','1')");
    alert("註冊完成");
    location("index.php");
}
//會員登出delete session
if (@$_GET['page'] == "logout") {
    @$_SESSION['state'] = "0";
    @$_SESSION['acc'] = "";
    location("index.php");
}
//農場體驗活動新增
if (@$_GET['page'] == "farmer_join_insert") {
    $JoinTime = $_POST['join_StartTime'] . "-" . $_POST['join_EndTime'];
    $s = 0;
    // echo $JoinTime . "　".$_POST['join_date'] ."　" . $_POST['join_nums'] . "　".$s ; 
    mysqli_query($con, "insert into farm_experience_manager values('','$_POST[join_date]','$JoinTime','$_POST[join_nums]',$s)");
    alert("農場體驗新增成功！");
    location("farmer_manager.php?page=farmer_join_manage");
}

//農場體驗預約_民眾新增(簡訊、)
if (@$_GET['page'] == "farmer_experience") {

    /*$rand = "Q W E R T Y U I O P A S D F G H J K L Z X C V B N M 1 2 3 4 5 6 7 8 9 0 q w e r t y u i o p a s d f g h j k l z x c v b n m";
    $rand = explode(" ", $rand);
    for ($i = 1; $i <= 10; $i++) {
        @$num = $num . $rand[rand(0, 61)];
    }*/
    $myfile = fopen("Farm_experience/$_POST[experience_name].txt", "w") or die(fopen("Farm_experience/$_POST[experience_name].txt", "a"));
    for ($i = 1; $i <= 40; $i++) {
        @$txt = $txt . "=";
    }
    fwrite($myfile, $txt);
    $txt = "\n\r\r　小農　農場體驗報名完成通知！ \n　活動場次：　" . $_POST['experience_no'] . "\n　活動日期：" . $_POST['experience_date'] . "　　" . $_POST['experience_time'] .
        "\n　參加人數：" . $_POST['experience_nums'] . "\n　聯絡人：" . $_POST['experience_name'] . ";　連絡電話：" . $_POST['experience_tel'] .
        "\n\n\n　收到此簡訊代表農場體驗報名成功！謝謝您，\n　如有任何問題，歡迎來電洽詢歐！";
    fwrite($myfile, $txt);
    fclose($myfile);

    $roe = mysqli_query($con, "select * from farm_experience_manager where no = '$_POST[experience_no]'");
    $farm_ex_m = mysqli_fetch_array($roe);
    $person = $farm_ex_m['experience_people'] + $_POST['experience_nums'];
    mysqli_query($con, "insert into farm_experience values('','$_POST[experience_no]','$_POST[experience_date]','$_POST[experience_time]','$_POST[experience_nums]','$_POST[experience_name]','$_POST[experience_tel]','$_POST[experience_mail]')");
    mysqli_query($con, "UPDATE farm_experience_manager SET experience_people = '$person' WHERE no = '$farm_ex_m[no]'");

    alert("報名成功！請確定是否收到簡訊");
    location("farmer_join.php");
}

//農產品訂購(簡訊、)
if (@$_GET['page'] == "order_two") {
    if ($_POST['ran'] == $_SESSION['ran']) {
        //編號亂數訂單編號
        $rand = "Q W E R T Y U I O P A S D F G H J K L Z X C V B N M 1 2 3 4 5 6 7 8 9 0 q w e r t y u i o p a s d f g h j k l z x c v b n m";
        $rand = explode(" ", $rand);
        for ($i = 1; $i <= 10; $i++) {
            @$num = $num . $rand[rand(0, 61)];
        }
        $myfile = fopen("Products/$_POST[o_phone].txt", "w") or die(fopen("Products/$_POST[o_phone].txt", "a"));
        for ($i = 1; $i <= 40; $i++) {
            @$txt = $txt . "=";
        }
        fwrite($myfile, $txt);
        $txt = "\n\r\r小農農產品訂購成功。\n訂單編號：" . $num . "\n訂購人姓名：" . $_POST['o_name'] . "；手機：" . $_POST['o_phone'] . "\n收件人姓名：" .
            $_POST['recipient_name'] . ";　連絡電話：" . $_POST['recipient_phone'] . "\n寄送地址：" . $_POST['recipient_addr'] . "\n產品名稱：香蕉果乾　　數量：" . $_POST['recipient_nums'] .
            "\n\n總計金額：" . $_POST['recipient_tot'] . "元(含運費)\n收到此簡訊代表訂購成功！謝謝您的購買，\n如有任何問題，歡迎來電洽詢";
        fwrite($myfile, $txt);
        fclose($myfile);
        mysqli_query($con, "insert into farm_order values('','$num','$_POST[o_name]','$_POST[o_phone]','$_POST[recipient_name]','$_POST[recipient_phone]','$_POST[recipient_addr]','$_POST[recipient_product]','$_POST[recipient_nums]','$_POST[recipient_UnitPrice]','$_POST[recipient_fare]','$_POST[recipient_tot]')");
        mysqli_query($con, "insert into farm_order_info values('','$num','$_POST[o_name]','$_POST[o_phone]','1')");
        alert("訂購成功，請收簡訊");
        location('index.php');
    } else {
        alert('驗證碼錯誤');
        echo "<script>history.back()</script>";
    }
}

?>