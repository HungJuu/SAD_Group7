<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>無標題文件</title>
    <style>
    .num {
        border: solid 2px #000000;
        padding: 2px;
    }
    </style>
</head>

<body>

    <?php
$num=array(4);
for($i=1 ; $i<=4 ;$i++){
	$array[$i]=rand(0,9);
	
?>
    <span class="num" draggable="true"
        ondragstart="event.dataTransfer.setData('text/plain','<?=$array[$i]?>')"><?=$array[$i]?></span>
    <?php	
	}
for($k=1 ;$k<=4 ;$k++){
	for($j=1 ;$j<=4 ;$j++){
		if($array[$k] <$array[$j]){
			$ram =$array[$k];
			$array[$k] =$array[$j];
			$array[$j] =$ram;
			}
		}
	}
$_SESSION['ran']=$array[1].$array[2].$array[3].$array[4];
?>
</body>

</html>