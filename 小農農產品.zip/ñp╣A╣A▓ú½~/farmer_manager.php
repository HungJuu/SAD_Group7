<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php"); ?>
    <script>
        function go() {
            history.go(-1);
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <div class="link">
            <ui>
                <li class="lil"><a href="index.php">首頁</a></li>
                <li class="lil_down">
                    <a href="">農產品訂購</a>
                    <div class="dropdown-content">
                        <a href="?page=manager_order_info">所有訂單資訊</a>
                    </div>
                </li>
                <li class="lil_down"><a href="#">農場體驗</a>
                    <div class="dropdown-content">
                        <a href="?page=farmer_join_manage">體驗清單</a>
                        <a href="?page=farmer_join_insert">活動新增</a>
                    </div>

                </li>
                <li class="lil"><a href="farmer_pro.php?page=logout">登　出</a></li>
            </ui>
        </div>
        <center>
            <?php if (@$_GET['page'] == "farmer_join_manage") {
                $roe = mysqli_query($con, "select * from farm_experience_manager");
                while ($roo = mysqli_fetch_array($roe)) {
            ?>
                    <div id="tb">
                        <table width="45%" height="35%" cellpadding="0" cellspacing="0" align="center">
                            <tr>
                                <td colspan="6" align="center" class="t1">活動場次：<?= $roo['no'] ?><br></td>
                            </tr>
                            <tr>
                                <td align="center">日　期</td>
                                <td align="center">時　段</td>
                                <td align="center">總預約人數</td>
                                <td align="center">剩餘名額</td>
                                <td align="center">報名狀況</td>
                            </tr>
                            <tr>
                                <td><?= $roo['experience_date'] ?></td>
                                <td><?= $roo['experience_time'] ?></td>
                                <td><?= $roo['experience_nums'] ?></td>
                                <td><?= $roo['experience_nums'] - $roo['experience_people'] ?></td>
                                <!--  <td><button class="JoinFarm" onclick="JoinFarm()">預　約</button></td>-->
                                <td><a href="?page=farmer_join_manage2&id=<?= $roo['no'] ?>">查　看</a></td>
                            </tr>
                        </table>
                    </div>
                <?php }
            }
            if (@$_GET['page'] == "farmer_join_manage2") {
                ?>
                <table width="45%" height="35%" cellpadding="0" cellspacing="0" align="center">
                    <tr>
                        <td colspan="5" align="center" class="t1">活動場次：<?= $_GET['id'] ?>　報名狀況<br></td>
                    </tr>
                    <tr>
                        <td>報名姓名</td>
                        <td>同行人數</td>
                        <td>連絡電話</td>
                    </tr>
                    <?php $roe = mysqli_query($con, "select * from farm_experience where no = '$_GET[id]'");
                    while ($roo = mysqli_fetch_array($roe)) {
                    ?>
                        <tr>
                            <td><?= $roo['experience_name'] ?></td>
                            <td><?= $roo['experience_nums'] ?></td>
                            <td><?= $roo['experience_tel'] ?></td>
                            <!--  <td><button class="JoinFarm" onclick="JoinFarm()">預　約</button></td>-->
                        </tr>
                    <?php   } ?>
                    <tr>
                        <td colspan="3" align="center"> <input type="button" onclick="go()" value="上一頁">
                        </td>
                    </tr>
                </table>
            <?php }
            if (@$_GET['page'] == "farmer_join_insert") {
            ?>
                <form action="farmer_pro.php?page=farmer_join_insert" method="post">
                    <table width="40%" height="35%" cellpadding="0" cellspacing="0" align="center">
                        <tr>
                            <td colspan="5" align="center" class="t1">農產體驗場次新增<br></td>
                        </tr>
                        <tr>
                            <td align="center">活動日期</td>
                            <td align="center"><input type="date" name="join_date"></td>
                        <tr>
                        <tr>
                            <td align="center">活動時間</td>
                            <td align="center"><input type="time" name="join_StartTime">　至　<input type="time" name="join_EndTime"></td>
                        <tr>
                        <tr>
                            <td align="center">可報名人數</td>
                            <td align="center"><input type="number" max="60" name="join_nums"> </td>
                        <tr>
                            <td colspan="2" align="center"> <br>
                                <input type="button" onclick="go()" value="上一頁">　
                                <input type="submit" value="送出活動">　
                                <input type="reset" value="清　除">
                            </td>
                        </tr>
                    </table>
                </form>
            <?php }
            if (@$_GET['page'] == "manager_order_info") {        ?>
                <div id="tb">
                    <table width="45%" height="35%" cellpadding="0" cellspacing="0" align="center">
                        <tr>
                            <td colspan="6" align="center" class="t1">香蕉果乾 訂單資訊<br></td>
                        </tr>
                        <tr>
                            <td align="center">訂單編號</td>
                            <td align="center">訂購人姓名</td>
                            <td align="center">出貨狀況</td>
                            <td align="center">詳細資訊</td>
                        </tr>
                        <?php
                        $roe = mysqli_query($con, "select * from farm_order_info");
                        while ($roo = mysqli_fetch_array($roe)) {
                            $order_status = "";
                            if ($roo['order_status'] == "1") {
                                $order_status = "備貨中";
                            }
                            if ($roo['order_status'] == "2") {
                                $order_status = "出貨中";
                            }
                            if ($roo['order_status'] == "3") {
                                $order_status = "正在送往指定地點";
                            }
                            if ($roo['order_status'] == "4") {
                                $order_status = "訂單已完成";
                            }
                        ?>
                            <tr>
                                <td><?= $roo['order_number'] ?></td>
                                <td><?= $roo['o_name'] ?></td>
                                <td><?= $order_status ?></td>
                                <td><a href="?page=manager_order_info2&id=<?= $roo['order_number'] ?>">查　看</a></td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>
            <?php }
            if (@$_GET['page'] == "manager_order_info2") {
                $ros = mysqli_query($con, "select * from farm_order where order_number = '$_GET[id]'");
                $roos = mysqli_fetch_array($ros)
            ?>
                <div id="tb">
                    <table width="45%" height="35%" cellpadding="0" cellspacing="0" align="center">
                        <tr>
                            <td align="center" colspan="2">訂單資訊</td>
                        </tr>
                        <tr>
                            <td align="left" colspan="2">　訂單編號：<span style="font-weight:bold;"><?= $roos['order_number'] ?></span>
                                （<?php
                                    $sta = mysqli_fetch_array(mysqli_query($con, "select * from farm_order_info where order_number = '$roos[order_number]'"));
                                    $order_status = "";
                                    if ($sta['order_status'] == "1") {
                                        $order_status = "備貨中";
                                    }
                                    if ($sta['order_status'] == "2") {
                                        $order_status = "出貨中";
                                    }
                                    if ($sta['order_status'] == "3") {
                                        $order_status = "正在送往指定地點";
                                    }
                                    if ($sta['order_status'] == "4") {
                                        $order_status = "訂單已完成";
                                    }
                                    ?><span style="color:red;font-weight:bolder; font-size: 20px;"><?= $order_status; ?></span>）
                                <p>
                                    　訂購人：<?= $roos['o_name'] ?>
                                <p>　訂購人電話：<?= $roos['o_phone'] ?>
                                <p>　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-　-</p>
                            </td>
                        </tr>
                        <tr vi>
                            <td align="left" width="55%">
                                　收件人：<?= $roos['recipient_name'] ?>
                                <p>
                                <p>　收購人電話：<?= $roos['recipient_phone'] ?>　　　　>>
                                <p>　收件地址：<?= $roos['recipient_addr'] ?>
                            </td>
                            <td align="left">
                                訂購產品：<?= $roos['recipient_product'] ?>
                                <p>
                                <p>產品數量：<?= $roos['recipient_nums'] ?>
                                <p>總計金額：<span style="color:red;font-weight:bolder; font-size: 20px;"><?= $roos['recipient_tot'] ?></span>　(含運)
                                <p>結帳狀態：貨到付款
                            </td>
                        </tr>
                        <tr>
                            <td align="center" colspan="2"><button onclick="go()" </butto>回上一頁</butto>
                            </td>
                        </tr>
                    </table>
                </div>
            <?php } ?>

        </center>
    </div>
</body>

</html>