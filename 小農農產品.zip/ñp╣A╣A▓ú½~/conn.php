<?php
$con = mysqli_connect("127.0.0.1","admin","1234");
mysqli_select_db($con,"farmer");
mysqli_query($con,"set names utf8");
session_start();
date_default_timezone_set("Asia/Taipei");

function alert($text){
	echo "<script>alert('$text')</script>";
}
function location($mark){
	echo "<script>location.replace('$mark')</script>";
}

?>