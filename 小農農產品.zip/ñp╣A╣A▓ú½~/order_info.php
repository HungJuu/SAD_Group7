<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php"); ?>

    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="JQ/jquery-3.2.1.js"></script>
    <script src="JQ/jquery-3.2.1.min.js"></script>
    <script>
        function booking() {

            sub.submit();

        }
        function jujube() {
            var s = document.getElementById("paragraph");
            if (s.style.display == "none") {
                s.style.display = "block";
            } else {
                s.style.display = "none";
            }
        }

        function mango() {
            var m = document.getElementById("fruit2");
            if (m.style.display == "none") {
                m.style.display = "block";
            } else {
                m.style.display = "none";
            }
        }

        function banana() {
            var y = document.getElementById("fruit3");
            if (y.style.display == "none") {
                y.style.display = "block";
            } else {
                y.style.display = "none";
            }
        }

        function cookies() {
            var y = document.getElementById("fruit4");
            if (y.style.display == "none") {
                y.style.display = "block";
            } else {
                y.style.display = "none";
            }
        }
        $(document).ready(function() {
            $("#date").change(function() {
                var d = new Date($("#date").val());
                $("#week").val("星期" + mo[d.getDay()]);
            })
            $("#recipient_nums").change(function() {
                $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
            })
            $("#recipient_UnitPrice").change(function() {
                $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
            })
            $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
        });

        function myFunction() {
            // Get the checkbox
            var checkBox = document.getElementById("myCheck");
            // Get the output text
            var text = document.getElementById("text");

            // If the checkbox is checked, display the output text
            if (checkBox.checked == true) {
                //           alert($("#o_name").val());
                $("#recipient_name").val($("#o_name").val());
                $("#recipient_phone").val($("#o_phone").val());
            } else {
                $("#recipient_name").val("");
                $("#recipient_phone").val("");
                text.style.display = "none";
            }
        }

        function go() {
            history.go(-1);
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <div class="link">
            <ui>
                <li class="lil"><a href="index.php">首頁</a></li>
                <li class="lil_down">
                    <a href="order.php?page=o_one">我要購買</a>
                    <div class="dropdown-content">
                        <a href="order_info.php?page=o_info">訂單資訊</a>
                    </div>
                </li>
                <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                <li class="lil"><a href="farmer_pro.php?page=logout">登　出</a></li>
            </ui>
        </div>
        <center>
            <?php if (@$_SESSION['state'] == "1") {
                if (@$_GET['page'] == "o_info") {
                    $roe = mysqli_query($con, "select * from users where acc = '$_SESSION[acc]'");
                    while ($roo = mysqli_fetch_array($roe)) {
            ?>
                        <div id="tb">
                            <!--  <form action="order_info_two.php?o_number=<?= $root_info['order_number'] ?>" method="get">-->
                            <table width="45%" height="35%" cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td colspan="5" align="center" class="t1">訂單資訊<br></td>
                                </tr>
                                <tr>
                                    <td align="center">筆　數</td>
                                    <td align="left">　　　　　　　　訂單編號</td>
                                    <td align="center">追蹤訂單</td>
                                </tr>
                                <?php {
                                    $root = mysqli_query($con, "select * from farm_order_info where o_name = '$roo[c_name]'");
                                    $no = mysqli_num_rows($root);
                                    if ($no > 0) {
                                        $nk = 1;
                                        while ($root_info = mysqli_fetch_array($root)) { ?>
                                            <tr>
                                                <td align="center"><input type="text" name="info_n" value="<?= $nk ?>" size="1" readonly style="border-style:none"></td>
                                                <td align="center"><input type="text" name="info_number" value="<?= $root_info['order_number'] ?>" size="13" readonly style="border-style:none"></td>
                                                <td align="center">
                                                    <a href="?page=o_info_two&o_number=<?= $root_info['order_number'] ?>">查看明細</a>
                                                </td>
                                            </tr>
                                    <?php $nk++;
                                        }
                                    } ?>
                                <?php /*while ($root_info = mysqli_fetch_array($root)) { ?>
                                    <tr>
                                        <td></td>
                                        <td><?=$root_info['order_number']?></td>
                                    </tr>
                            <?php }*/
                                } ?>
                            </table>
                            <!-- </form> -->
                        </div>
                    <?php
                    }
                }
                if (@$_GET['page'] == "o_info_two") {
                    $roe = mysqli_query($con, "select * from farm_order_info where order_number = '$_GET[o_number]'");
                    while ($roo = mysqli_fetch_array($roe)) {
                        //echo $roo['o_name']; 
                    ?>
                        <div id="tb">
                            <!--  <form action="order_info_two.php?o_number=<?= $root_info['order_number'] ?>" method="get">-->
                            <table width="55%" height="35%" cellpadding="0" cellspacing="0" align="center">
                                <tr>
                                    <td colspan="5" align="center" class="t1">訂單明細<br></td>
                                </tr>
                                <tr>
                                    <td align="left">　訂單編號　　<?= $roo['order_number'] ?></td>
                                </tr>
                                <tr>
                                    <td align="left">　訂單狀態</td>
                                </tr>
                                <tr>
                                    <?php if ($roo['order_status'] == "1") { ?>
                                        <td><span style="color:red;font-weight:bold; font-size: 20px;">備貨中</span>---------->出貨中---------------> 送往目的地(2天內抵達)------->已完成訂單</td>
                                    <?php } else if ($roo['order_status'] == "2") { ?>
                                        <td>備貨中---------><span style="color:red;font-weight:bold; font-size: 20px;">●出貨中</span>---------------> 送往目的地(2天內抵達)------->已完成訂單</td>
                                    <?php } else if ($roo['order_status'] == "3") { ?>
                                        <td>備貨中--------->出貨中---------------><span style="color:red;font-weight:bold; font-size: 20px;">●送往目的地(2天內抵達)</span>------->已完成訂單</td>
                                    <?php } else if ($roo['order_status'] == "4") { ?>
                                        <td>備貨中--------->出貨中--------------->送往目的地(2天內抵達)-------><span style="color:green;font-weight:bolder; font-size: 20px;">已完成訂單</span></td>

                                    <?php } ?>
                                </tr>
                                <tr>
                                    <td align="left">　訂購人：　　<?= $roo['o_name'] ?></td>
                                </tr>
                                <tr>
                                    <td align="left">　訂購人手機　　<?= $roo['o_phone'] ?></td>
                                </tr>
                                <?php $roo_info = mysqli_query($con, "select * from farm_order where order_number = '$roo[order_number]'");
                                while ($roo_infos = mysqli_fetch_array($roo_info)) {

                                ?>
                                    <tr>
                                        <td align="left">　商品名稱　　<?= $roo_infos['recipient_product'] ?></td>
                                    </tr>
                                    </tr>
                                    <td align="left">　訂購總金額　　<?= $roo_infos['recipient_tot'] ?></td>
                                    </tr>
                                    <tr>
                                        <td align="left">　支付方式：貨到付款</td>
                                    </tr>
                                    </tr>
                                    <td align="left">　收件人：　　<?= $roo_infos['recipient_name'] ?></td>
                                    </tr>
                                    <td align="left">　收件地址：　　<?= $roo_infos['recipient_addr'] ?></td>
                                    </tr><?php } ?>
                                <tr>
                                    <td>
                                        <input type="button" onclick="go()" value="上一頁">
                                    </td>
                                </tr>
                            </table>
                            <!-- </form> -->
                        </div>


            <?php }
                }
            } else {
                alert('請先登入');
                location("farmer_login.php");
            } ?>
    </div>
</body>

</html>