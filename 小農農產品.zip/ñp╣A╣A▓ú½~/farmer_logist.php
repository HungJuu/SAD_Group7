<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php"); ?>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="JQ/jquery-3.2.1.js"></script>
    <script src="JQ/jquery-3.2.1.min.js"></script>
    <script>
        function logist() {
            var mun = 0;
            // /[@#\$%\^&\*]+/g
            // new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]","i"); 
            var er = /[{}!@#$%^&*()_+='" ]+/;

            var text = $('#c_tel').val()
            if (er.test(text) == true) {
                alert('出現非法文字');
            }

            if ($('#c_name').val() == "") {
                alert('姓名不得為空值');
            } else {
                mun += 1;
            }
            if ($('#acc').val() == "") {
                alert('帳號不得為空值');
            } else {
                mun += 1;
            }
            if ($('#password').val() == "") {
                alert('密碼不得為空值');
            } else {
                mun += 1;
            }
            if ($('#c_mail').val() == "") {
                alert('電子信箱不得為空值');
            } else {
                mun += 1;
            }
            if ($('#c_tel').val() == "") {
                alert('手機號碼不得為空值');
            } else {
                mun += 1;
            }
            if ($('#identity').val() == "") {
                alert('身分別不得為空值');
            } else {
                mun += 1;
            }
            if (mun == 6) {
                sub.submit();
            }
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <div class="link">
            <ui>
                <li class="lil"><a href="index.php">首頁</a></li>
                <li class="lil_down">
                    <a href="order.php?page=o_one">我要購買</a>
                    <div class="dropdown-content">
                        <a href="order_info.php?page=o_info">訂單資訊</a>
                    </div>
                </li>
                <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                <li class="lil"><a href="farmer_login.php">會員登入</a></li>
            </ui>
        </div>
        <center>
            <form method="post" id="sub" action="farmer_pro.php?page=logist">
                <table width="30%" border="0" cellspacing="0">
                    <tr>
                        <td colspan="2" class="t1">會員註冊</td>
                    </tr>
                    <tr>
                        <td width="27%">姓　名</td>
                        <td width="73%"><input type="text" name="c_name" id="c_name"></td>
                    </tr>
                    <tr>
                        <td width="27%">帳 號</td>
                        <td width="73%"><input type="text" name="acc" id="acc"></td>
                    </tr>
                    <tr>
                        <td>密 碼</td>
                        <td><input type="password" name="password" id="password"></td>
                    </tr>
                    <tr>
                        <td>電子信箱</td>
                        <td><input type="text" name="c_mail" id="c_mail"></td>
                    </tr>
                    <tr>
                        <td>手機號碼</td>
                        <td><input type="text" name="c_tel" id="c_tel"></td>
                    </tr>
                    <tr>
                        <td>身分別</td>
                        <td>
                            <input type="radio" name="identity" value="cutomer" id="identity">顧　客　
                            <input type="radio" name="identity" value="company" id="identity">公司行號
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="button" onClick="logist()" value="送出">
                            <input type="reset" value="清除">
                        </td>
                    </tr>
                </table>
            </form>
        </center>
    </div>
</body>

</html>