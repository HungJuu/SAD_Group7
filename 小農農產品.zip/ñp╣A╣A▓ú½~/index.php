<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php"); ?>
    <script>
        function HaveToKnow_button() {
            document.getElementById("HaveToKnow").style.display = "none";
            //  game = true;
            document.getElementById("FruitIntroduce").style.display = "block";
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <?php if (@$_SESSION['state'] == "1") { ?>
            <div class="link">
                <ui>
                    <li class="lil"><a href="index.php">首頁</a></li>
                    <li class="lil_down">
                        <a href="order.php?page=o_one">我要購買</a>
                        <div class="dropdown-content">
                            <a href="order_info.php?page=o_info">訂單資訊</a>
                        </div>
                    </li>
                    <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                    <li class="lil"><a href="farmer_pro.php?page=logout">登　出</a></li>
                </ui>
            </div>

        <?php } else { ?>
            <div class="link">
                <ui>
                    <li class="lil"><a href="index.php">首頁</a></li>
                    <li class="lil_down">
                        <a href="order.php?page=o_one">我要購買</a>
                        <div class="dropdown-content">
                            <a href="order_info.php">訂單資訊</a>
                        </div>
                    </li>
                    <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                    <div id="log">
                        <li class="lil"><a href="farmer_login.php">會員登入</a></li>
                    </div>
                </ui>
            </div>
        <?php } ?>

        <center>
            <div id="HaveToKnow">
                <font size="+2">
                    <center>小　農　農　購　買　須　知</center>
                </font>
                <hr size="3" color="#999" width="80%">
                <marquee direction="up" height="310" onMouseOver="this.stop()" onMouseOut="this.start()" scrolldelay="200" loop="1">
                    <Center>
                        <h2>/ 購 買 前 須 知 /</h2>
                    </Center>
                    ★ 本平台僅以販售「現貨」商品，工作天不包含假日，不能等待請勿下單。<p>
                        ★ 下單後不接受取消訂單!!!
                    <p>
                        ★ 若商品有瑕疵或寄錯問題請於上班時間洽詢客服，若商品需要換貨(來回運費需自付)。
                    <p>
                        ★ 不接受因個人因素(色差.不喜歡.不適合等問題)退貨，詳情請點 : 退換貨政策
                    <p>
                        ★ 隨意棄單或無故未收包裹一律加入黑名單，若有任何問題都可以洽詢客服。
                    <p>
                    <p>

                        <Center>
                            <h2>/ 購 物 流 程 /</h2>
                        </Center><br>
                        ★ 登入會員→選購商品加入購物車→結帳→填寫收件人資料(務必正確無誤)→選擇付款方式(貨到付款、線上付款)
                    <p>
                        ★ 下單前記得登入會員！
                    <p>
                        ★ 若要確認訂單狀況，請登入會員選擇「訂單管理」，若有斷/缺貨通知，將會在網頁通知。
                    <p>
                        ★ 我們所提供的產品配送區域僅限於台灣本島，運費$130。
                    <p>
                </marquee>
                <div>
                    <button class="HaveToKnow_buttion" onClick="HaveToKnow_button()">我已充分了解！</button>
                </div>
            </div>
            <div id="FruitIntroduce">
                <table width="50%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td colspan="2" align="center" class="t1">水果介紹</td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>
                            <h3><b>旗山香蕉🍌</b></h3>
                            旗山位於高雄山區和平原的交界，擁有適宜的氣候條件和優越的地理環境，<br>
                            使得種植出來的香蕉帶有獨特的香氣，綿密甜Q、風味馥郁，有「香蕉王國」之稱；<br>
                            近年來，旗山蕉農轉型成為優質小農，使得所種植出來的香蕉品質更加精緻且穩定。<br>
                            <h3><b>蜜 棗🍏</b></h3>
                            燕巢區的「蜜棗」，由於甜度高、肉質細、著果性佳、採收期長且耐保存，成為台灣<br>
                            最重要、種植最廣的棗子品種。含有豐富的維他命C、A1、B1，有「天然維他命C丸」<br>
                            的美稱，養顏美容⭐️又助消化，是健康的優質水果。燕巢農民通常以雞蛋、鮮奶、豆餅、<br>
                            米糠等有機養料，再加入獨家配方發酵製成的蜜棗大補帖，營養豐富，果樹也容易消化，<br>
                            加上泥火山青灰岩土質的養分，成就了蜜棗的獨特美味。<br>
                            <h3><b>芭 樂🍐</b></h3>
                            低熱量、高纖維、水分高，易有飽足感之水果，是糖尿病和減肥者的最佳選擇之一。<br>
                            因屬熱帶高維他命Ｃ水果，亦為天然美白的聖品，對於牙齦健康也有幫助。也是人體攝取<br>
                            維他命C最重要的來源。同時富含維生素，纖維與抗氧化劑的番石榴更是天然的防老抗癌防癌的水果。<br>
                            <h3><b>土芒果🥭</b></h3>
                            最大的特點為抗病蟲害強，耐旱因此管理容易，果實具有濃郁的香味，外皮為黃綠色的土芒果，<br>
                            果實雖小且纖維粗，但酸甜有味、香氣濃郁，常被用於製作情人果、蜜餞、芒果乾。台灣人<br>
                            吃遍大大小小芒果後，才驚覺那長在高高樹上的小小土芒果，才是最香、最甜、最好吃的品種，<br>
                            有土芒果獨有的香氣美味。<br>
                        </td>
                        <!--<td><a href="#"><img class="img-fluid" title ="longan"src="image\longan.jpg" alt="longan" width="200" height="200" /></a><br>
                    </td>-->
                    </tr>
                </table>
            </div>
        </center>
    </div>
</body>

</html>