<!DOCTYPE html>
<html>

<head>
    <?php include("conn.php"); ?>

    <script>
        function displaySong1() {
            /*            var p = document.getElementById("paragraph");
                        p.style.display = "block";*/
            var x = document.getElementById("paragraph");
            if (x.style.display == "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }

        }
    </script>
    <link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
    <button class="button button1" onclick="displaySong1()">Easy</button>
    <div id="paragraph">
        高雄市燕巢區蜜棗種植面積約600公頃，年產量3000多公噸蜜棗的指標性產區。蜜棗產期是國曆12月下旬
        至翌年3月上旬，盛產期在1月。為保持蜜棗品質，每年產季過後，農民們須像望子成龍的父親一般，對蜜棗樹
        徹底的截枝，只留下小腿一般高的樹幹，讓果樹重新來過。
    </div>

    <form method="post" id="sub" action="test.php?page='test'">
        <table width="30%" border="0" cellspacing="0">
            <tr>
                <td>身分別</td>
                <td>
                    <input type="radio" name="identity" value="cutomer" id="identity">顧　客　
                    <input type="radio" name="identity" value="company" id="identity">公司行號
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" value="送出">
                    <input type="reset" value="清除">
                </td>
            </tr>
        </table>
    </form>
    <?php if (@$_GET['page'] == "test") {
        alert("1");
    } ?>


</body>

</html>