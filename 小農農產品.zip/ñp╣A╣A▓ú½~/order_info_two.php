<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php"); ?>

    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="JQ/jquery-3.2.1.js"></script>
    <script src="JQ/jquery-3.2.1.min.js"></script>
    <script>
        function booking() {

            sub.submit();

        }

        function jujube() {
            var s = document.getElementById("paragraph");
            if (s.style.display == "none") {
                s.style.display = "block";
            } else {
                s.style.display = "none";
            }
        }

        function mango() {
            var m = document.getElementById("fruit2");
            if (m.style.display == "none") {
                m.style.display = "block";
            } else {
                m.style.display = "none";
            }
        }

        function banana() {
            var y = document.getElementById("fruit3");
            if (y.style.display == "none") {
                y.style.display = "block";
            } else {
                y.style.display = "none";
            }
        }

        function cookies() {
            var y = document.getElementById("fruit4");
            if (y.style.display == "none") {
                y.style.display = "block";
            } else {
                y.style.display = "none";
            }
        }
        $(document).ready(function() {
            $("#date").change(function() {
                var d = new Date($("#date").val());
                $("#week").val("星期" + mo[d.getDay()]);
            })
            $("#recipient_nums").change(function() {
                $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
            })
            $("#recipient_UnitPrice").change(function() {
                $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
            })
            $("#recipient_tot").val($("#recipient_nums").val() * $("#recipient_UnitPrice").val() + 130);
        });

        function myFunction() {
            // Get the checkbox
            var checkBox = document.getElementById("myCheck");
            // Get the output text
            var text = document.getElementById("text");

            // If the checkbox is checked, display the output text
            if (checkBox.checked == true) {
                //           alert($("#o_name").val());
                $("#recipient_name").val($("#o_name").val());
                $("#recipient_phone").val($("#o_phone").val());
            } else {
                $("#recipient_name").val("");
                $("#recipient_phone").val("");
                text.style.display = "none";
            }
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <div class="link">
            <ui>
                <li class="lil"><a href="index.php">首頁</a></li>
                <li class="lil_down">
                    <a href="order.php?page=o_one">我要購買</a>
                    <div class="dropdown-content">
                        <a href="order_info.php?page=o_info">訂單資訊</a>
                    </div>
                </li>
                <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                <li class="lil"><a href="farmer_pro.php?page=logout">登　出</a></li>
            </ui>
        </div>
        <center>
            <?php if (@$_SESSION['state'] == "1") {
                    
                    $roe = mysqli_query($con, "select * from farm_order_info where order_number = '$_POST[order_number]'");
                    while ($roo = mysqli_fetch_array($roe)) {
                        echo $_POST['order_number'];
                    }
                    echo $_POST['order_number'];
            } else {
                alert('請先登入');
                location("farmer_login.php");
            } ?>
    </div>
</body>

</html>