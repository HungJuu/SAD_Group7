-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- 主機: 127.0.0.1
-- 產生時間： 
-- 伺服器版本: 10.1.33-MariaDB
-- PHP 版本： 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `hsr`
--

-- --------------------------------------------------------

--
-- 資料表結構 `station`
--

CREATE TABLE `station` (
  `id` int(11) NOT NULL,
  `station_ch` varchar(20) COLLATE utf8_bin NOT NULL,
  `station_eng` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- 資料表的匯出資料 `station`
--

INSERT INTO `station` (`id`, `station_ch`, `station_eng`) VALUES
(1, '南港站', 'Nangang Station'),
(2, '臺北站', 'Taipei Station'),
(3, '板橋站', 'Banqiao Station'),
(4, '桃園站', 'Taoyuan Station'),
(5, '新竹站', 'Hsinchu Station'),
(6, '苗栗站', 'Miaoli Station'),
(7, '臺中站', 'Taichung Station'),
(8, '彰化站', 'Changhua Station'),
(9, '雲林站', 'Yunlin Station'),
(10, '嘉義站', 'Chiayi Station'),
(11, '台南站', 'Tainan Station'),
(12, '左營站', 'Zuoying Station'),
(13, '左營站', 'NKUST'),
(15, '高雄科技大學', 'nkfust'),
(20, '鼓山站2', 'school'),
(21, '鳳山站', 'KH'),
(22, '鳳山', 'abceee');

-- --------------------------------------------------------

--
-- 資料表結構 `time`
--

CREATE TABLE `time` (
  `id` int(11) NOT NULL,
  `date` text COLLATE utf8_bin NOT NULL,
  `time` text COLLATE utf8_bin NOT NULL,
  `week` text COLLATE utf8_bin NOT NULL,
  `box` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  `start_station` int(11) NOT NULL,
  `end_station` int(11) NOT NULL,
  `look` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- 資料表的匯出資料 `time`
--

INSERT INTO `time` (`id`, `date`, `time`, `week`, `box`, `person`, `start_station`, `end_station`, `look`) VALUES
(1, '2021-06-18', '21:00:00', '星期五', 5, 11, 7, 11, 1);

-- --------------------------------------------------------

--
-- 資料表結構 `time_info`
--

CREATE TABLE `time_info` (
  `id` int(11) NOT NULL,
  `timeid` int(11) NOT NULL,
  `time_drive` int(11) NOT NULL,
  `time_stop` int(11) NOT NULL,
  `money` int(11) NOT NULL,
  `station_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- 資料表的匯出資料 `time_info`
--

INSERT INTO `time_info` (`id`, `timeid`, `time_drive`, `time_stop`, `money`, `station_id`) VALUES
(5, 1, 0, 0, 0, 7),
(6, 1, 20, 5, 20, 8),
(7, 1, 15, 5, 10, 9),
(8, 1, 30, 5, 40, 10),
(9, 1, 15, 5, 25, 11);

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `time`
--
ALTER TABLE `time`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `time_info`
--
ALTER TABLE `time_info`
  ADD PRIMARY KEY (`id`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `station`
--
ALTER TABLE `station`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- 使用資料表 AUTO_INCREMENT `time`
--
ALTER TABLE `time`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用資料表 AUTO_INCREMENT `time_info`
--
ALTER TABLE `time_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
