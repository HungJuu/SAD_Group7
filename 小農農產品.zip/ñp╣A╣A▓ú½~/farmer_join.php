<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>小農農產品</title>
    <link href="css.css" rel="stylesheet" type="text/css">
    <?php include("conn.php");
    $backGround = "image/POST.png"; ?>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="JQ/jquery-3.2.1.js"></script>
    <script src="JQ/jquery-3.2.1.min.js"></script>
    <script>
        function JoinToKnow_button() {
            document.getElementById("JoinToKnow").style.display = "none";
            //  game = true;
            document.getElementById("JoinFarm").style.display = "block";
        }

        function JoinFarm() {
            document.getElementById("JoinFarm").style.display = "none";

            //  game = true;
            document.getElementById("JoinToKnow").style.display = "none";
            document.getElementById("JoinFarm_2").style.display = "block";

        }

        function join() {
            var mun = 0;
            // /[@#\$%\^&\*]+/g
            // new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]","i"); 
            var er = /[{}!@#$%^&*()_+='" ]+/;

            var text = $('#join_tel').val()
            if (er.test(text) == true) {
                alert('出現非法文字');
            }

            if ($('#join_name').val() == "") {
                alert('請輸入聯絡人姓名');
            } else {
                mun += 1;
            }
            if ($('#join_date').val() == "") {
                alert('請選擇參加日期');
            } else {
                mun += 1;
            }
            if ($('#join_nums').val() == "") {
                alert('請選擇參加人數');
            } else {
                mun += 1;
            }
            if ($('#join_mail').val() == "") {
                alert('電子信箱不得為空值');
            } else {
                mun += 1;
            }
            if ($('#join_tel').val() == "") {
                alert('請輸入聯絡人手機號碼');
            } else {
                mun += 1;
            }
            if ($('#join_ver').val() == "") {
                alert('請輸入驗證碼');
            } else {
                mun += 1;
            }
            if (mun == 6) {
                sub.submit();
            }
        }
    </script>
</head>

<body>
    <div>
        <div class="top-l">小農農產品</div>
        <?php if (@$_SESSION['state'] == "1") { ?>
            <div class="link">
                <ui>
                    <li class="lil"><a href="index.php">首頁</a></li>
                    <li class="lil_down">
                        <a href="order.php?page=o_one">我要購買</a>
                        <div class="dropdown-content">
                            <a href="order_info.php?page=o_info">訂單資訊</a>
                        </div>
                    </li>
                    <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                    <li class="lil"><a href="farmer_pro.php?page=logout">登　出</a></li>
                </ui>
            </div>
        <?php } else { ?>
            <div class="link">
                <ui>
                    <li class="lil"><a href="index.php">首頁</a></li>
                    <li class="lil_down">
                        <a href="order.php?page=o_one">我要購買</a>
                        <div class="dropdown-content">
                            <a href="order_info.php">訂單資訊</a>
                        </div>
                    </li>
                    <li class="lil"><a href="farmer_join.php">農場預約</a></li>
                    <div id="log">
                        <li class="lil"><a href="farmer_login.php">會員登入</a></li>
                    </div>
                </ui>
            </div>
        <?php } ?>
        <center>
            <div id="JoinToKnow">
                <font size="+2">
                    <center>小　農　體　驗　須　知</center>
                </font>
                <hr size="3" color="#999" width="80%">
                <marquee direction="up" height="310" onMouseOver="this.stop()" onMouseOut="this.start()" scrolldelay="200" loop="1">
                    <Center>
                        <h2> 蜜　棗　季 </h2>
                    </Center>
                    　　現在正值蜜棗盛產的季節,在xx休閒農場以種植蜜棗為主,在2月時開放讓民眾體驗<p>
                        採果的樂趣。小農農場的主人心整理果園,果園用紗網覆罩著,園內果蠅蚊蟲相對起來
                    <p>
                        較少,提供乾淨舒適的空間以牛奶栽培、減少噴藥次數,提供遊客最佳的採果品質,
                    <p>
                        可以吃到最健康、最自然的蜜棗。
                    <p>
                        　　現也有設置洗手台,讓遊客清洗水果現採試吃,x的蜜棗果樹不會太高,小朋友也能
                    <p>
                        輕易採摘, 農場主人會先告知採蜜的技巧還有如何挑選蜜棗,接著拿起剪刀,選擇喜歡的蜜棗即可下手。
                    <p>
                        祝大家玩得愉快~<br>
                </marquee>
                <div>
                    <button class="JoinToKnow_buttion" onClick="JoinToKnow_button()">小農知道了！</button>
                </div>
            </div>

            <div id="JoinFarm">
                <div id="imgs">
                    <img class="img-fluid" title="experience" src="image\POST.png" alt="banana" width="250" height="350" />
                </div>
                <!--   <form method="POST" action="farmer_join2.php" id="sub">-->
                <div id="tb">
                    <table width="45%" height="35%" cellpadding="0" cellspacing="0" align="center">
                        <tr>
                            <td colspan="5" align="center" class="t1">一日棗農體驗場次<br></td>
                        </tr>
                        <tr>
                            <td align="center">場　次</td>
                            <td align="center">日　期</td>
                            <td align="center">時　段</td>
                            <td align="center">可預約人數</td>
                            <td align="center">預　約</td>
                        </tr>
                        <?php
                        $roe = mysqli_query($con, "select * from farm_experience_manager");
                        while ($roo = mysqli_fetch_array($roe)) {
                            //  $ex = mysqli_query($con, "select * from farm_experience where no = '$roo[no]'");
                            //  while ($ex2 = mysqli_fetch_array($ex)) {
                        ?>
                            <tr>
                                <td><?= $roo['no'] ?></td>
                                <td><?= $roo['experience_date'] ?></td>
                                <td><?= $roo['experience_time'] ?></td>
                                <td><?= $roo['experience_nums'] - $roo['experience_people'] ?></td>
                                <!--  <td><button class="JoinFarm" onclick="JoinFarm()">預　約</button></td>-->
                                <td><a href="farmer_join2.php?id=<?= $roo['no'] ?>">報　名</a></td>
                            </tr>
                        <?php //}
                        } ?>
                    </table>
                </div>
                <div id="imgs2">
                    <img class="img-fluid" title="experience" src="image\POST.png" alt="banana" width="250" height="350" />
                </div>

                <div id="JoinFarm">

                    <!-- </form>-->
                </div>
            </div>
        </center>
</body>

</html>